class Header extends HTMLElement {
  constructor() {
    super();
    this.cart = localStorage.getItem("cart_counter") || 0;

    this.innerHTML = `<header>
  <div class="logo-container">
    <a href="index.html">
      <picture class="logo">
        <img
          src="amita_logo.webp.png"
          alt="Amita Logo"
          width="100px"
          height="94px"
        />
      </picture>
    </a>
    <div class="header-title">Amita Cake Studio</div>
  </div>
  <nav class="head_menu">
    <ul>
      <li><a href="index.html">Нүүр хуудас</a></li>
      <li><a href="product.html">Бүтээгдэхүүн</a></li>
      <li><a href="order.html">Захиалга</a></li>
      <li><a href="aboutUs.html">Бидний тухай</a></li>
      <li><a href="delivery.html">Манай хаяг</a></li>
    </ul>
    <section class="header_cart">
      <div id="circle"><p id="add">${this.cart}</p></div>
      <i class="fa-solid fa-cart-shopping" id="cart" style="font-size: 20px"></i>
      <button type="submit">Захиалга</button>
    </section>
    <section class="menu_bar"><i class="fa-solid fa-bars"></i></section>
  </nav>
</header>

       `;
  }

  connectedCallback() {}

  disconnectCallback() {}

  attributeChangedCallback(attrName, oldVal, newVal) {}
}

window.customElements.define("header-part", Header);

class Footer extends HTMLElement {
  constructor() {
    super();
    this.innerHTML = `    <footer>
    <section class="footer_top_section">
      <section class="footer_logo">
        <picture>
          <source
            srcset="path/to/image-large.jpg"
            media="(min-width: 800px)"
          />
          <source
            srcset="path/to/image-medium.jpg"
            media="(max-width: 500px)"
          />
          <a href="#"
            ><img
              src="amita_logo.webp.png"
              alt="Amita Logo"
              width="70%"
          /></a>
    <nav class="head_menu">
        </picture>
      </section>

      <article class="about_us">
        <h3>БИДНИЙ ТУХАЙ</h3>
        <ul>
          <li>
            <a href="aboutUs.html
            ">Бидний тухай</a>
          </li>
          <li>
            <a href="#">Нийгмийн хариуцлага</a>
          </li>
        </ul>
      </article>

      <article class="about_us">
        <h3>ТУСЛАМЖ ҮЙЛЧИЛГЭЭ</h3>
        <ul>
          <li>
            <a href="#">Илчлэгийн мэдээлэл</a>
          </li>
          <li>
            <a href="https://www.facebook.com/messages/t/706153162835219">Холбоо барих</a>
          </li>
        </ul>
      </article>

      <address class="join_us">
        <h3>БИДЭНТЭЙ НЭГДЭХ</h3>
        <ul>
          <li>
            <a href="https://www.facebook.com/Amita.cakestudio">
              <i class="fa-brands fa-facebook"></i>
              <p>Facebook</p>
            </a>
          </li>
          <li>
            <a href="https://www.instagram.com/amita.cakestudio/">
              <i class="fa-brands fa-instagram"></i>
              <p>Instagram</p>
            </a>
          </li>
        </ul>
      </address>

      <section class="comment">
        <h3>САНАЛТ ХҮСЭЛТ</h3>

        <section>
          <section class="input1">
            <div>
              <label for="email">Эмайл</label>
              <input
                type="email"
                name="mail"
                id = "email"
                placeholder="tlmn0153@gmail.com"
              />
              <br />
            </div>
            <div>
              <label for="phone">Утас</label>
              <input type="text" name="mail" class ="phone" placeholder="+976 ########" />
              <br />
            </div>
          </section>

          <section class="input_text">
            <div>
              <label for="message">Мессеж</label>
              <textarea
                name="message"
                id="message"
                class="texting"
              ></textarea>
            </div>
            <div class="button", id="feedbackBtn">
              <input type="submit" value="Илгээх" />
            </div>
         
          </section>
        </section>
      </section>
    </section>

    <section class="footer_bottom_section">
      <p>
        2025 Монголын анхны Бялуу захиалгын веб сайт 'Respect for Amita cake Studio</a>
      </p>
    </section>
  </footer>
    `;
  }
  connectedCallback() {
    const feedBtn = document.getElementById("feedbackBtn");
    feedBtn.addEventListener("click", () => {
      console.log("orlooo");
      const email = document.getElementById("email").value;
      const phone = document.getElementsByClassName("phone")[0].value;
      const message = document.getElementById("message").value;
      const data = { email, phone, message };
      console.log(email, phone, message);

      const succ = fetch("http://localhost:3000/feedback", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      });
      if (succ.ok) {
        console.log("success");
      } else console.log("not");
    });
    // console.log(feedBackButton);
  }
}

window.customElements.define("footer-part", Footer);

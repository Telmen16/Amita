document.querySelectorAll('.menu ul li').forEach((menuItem) => {
  menuItem.addEventListener('click', (event) => {
    const category = event.target.dataset.category; // data-category-г ашиглана
    const allProducts = document.querySelectorAll('.myproduct');
    
    allProducts.forEach((product) => {
      if (category === 'all' || product.dataset.category === category) { // "all" ангилал бүх бүтээгдэхүүнийг харуулна
        product.style.display = 'block';
      } else {
        product.style.display = 'none'; 
      }
    });
  });
});

document.addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('add-to-cart')) {
      const productId = e.target.getAttribute('data-id');
      addToCart(productId);
    }
  });
  
  function addToCart(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Бүтээгдэхүүн бүрт unique ID ашиглан сагсанд нэмнэ
    const product = cart.find(item => item.id == productId);
    
    if (product) {
      product.quantity++;
    } else {
      const productToAdd = { id: productId, quantity: 1 };
      cart.push(productToAdd);
    }
  
    // Сагсны агуулгыг хадгалах
    localStorage.setItem('cart', JSON.stringify(cart));
  
    // Сагсны тоог шинэчилнэ
    updateCartCount();
  }
  
  function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
    document.getElementById('add').textContent = cartCount;
  }
  
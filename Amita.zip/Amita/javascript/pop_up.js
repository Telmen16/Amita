document.addEventListener('DOMContentLoaded', function() {
    // Сагсанд бүтээгдэхүүн нэмэх код
    const addToCartButtons = document.querySelectorAll('.myproduct button');
    const cartFullSection = document.querySelector('.cart_full');
    const cartEmptySection = document.querySelector('.cart_empty');
    const totalPriceElement = document.getElementById('total_price');
    let totalPrice = 0;
    const cartItems = [];

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productCard = this.closest('.myproduct');
            const productName = productCard.querySelector('h3').textContent;
            const productPriceText = productCard.querySelector('p').textContent;
            
            const productPrice = parseInt(productPriceText.replace(/[₮,]/g, '').trim());

            cartItems.push({ name: productName, price: productPrice });
            totalPrice += productPrice;

            updateCart();
        });
    });

    function updateCart() {
        if (cartItems.length === 0) {
            cartEmptySection.style.display = 'block';
            cartFullSection.style.display = 'none';
        } else {
            cartEmptySection.style.display = 'none';
            cartFullSection.style.display = 'block';

            cartFullSection.innerHTML = ''; // Clear previous cart content

            cartItems.forEach(item => {
                const cartItem = document.createElement('div');
                cartItem.classList.add('cart_item');
                cartItem.innerHTML = `<p>${item.name}</p><p>${item.price.toLocaleString()}₮</p>`;
                cartFullSection.appendChild(cartItem);
            });

            totalPriceElement.textContent = totalPrice.toLocaleString() + '₮';
        }
    }

    // Категори шүүлтүүр код
    const filterButtons = document.querySelectorAll(".menu ul li a");
    const products = document.querySelectorAll(".myproduct");

    filterButtons.forEach(button => {
        button.addEventListener("click", (e) => {
            e.preventDefault(); // Prevent page reload

            const category = button.dataset.category; // Get category from data-category
            products.forEach(product => {
                // Бүтээгдэхүүний категори гэж шалгадаг хэсэг
                if (category === "all" || product.dataset.category === category) {
                    product.style.display = "block"; // Show the product
                } else {
                    product.style.display = "none"; // Hide the product
                }
            });
        });
    });
});

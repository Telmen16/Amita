fetch('./json/products.json')
  .then(response => response.json())  // JSON ачаалж байна
  .then(data => {
    loadProducts(data.products);  // Үр дүнг products массив болгон дамжуулна
  })
  .catch(error => console.error('JSON ачааллахад алдаа гарлаа:', error));

function loadProducts(products) {
  const cakeSection = document.getElementById('cake');  // Бүтээгдэхүүн гаргах хэсэг

  products.forEach(product => {
    const productElement = document.createElement('article');
    productElement.classList.add('myproduct');
    productElement.setAttribute('data-name', `p-${product.id}`);
    productElement.setAttribute('data-category', product.category);

    productElement.innerHTML = `
      <a href="#">
        <picture>
          <img src="${product.image}" alt="${product.name}">
        </picture>
      </a>
      <h3>${product.name}</h3>
      <p>${product.price}</p>
      <button type="submit">Сагсанд нэмэх</button>
    `;
    cakeSection.appendChild(productElement);  // Элементээ дэлгэцэнд нэмнэ
  });
}
